use Financedata; 

select*from finance_1;
select*from finance_2;

# Total Loan Amount
Select sum(loan_amnt) total_loan_amount from finance_1;

# Total loan issued
Select distinct count(member_id) as number_of_loan_issued
from finance_1;


# KPI 1 Year wise loan amount Stats
select year(issue_d) as issue_years, sum(loan_amnt) as total_amount
from finance_1
group by issue_years
order by total_amount desc;


#KPI 2 Grade and sub grade wise revol_bal
Select f1.grade, f1.sub_grade, sum(f2.revol_bal) as revolving_bal
from finance_1 as f1 inner join finance_2 as f2
on f1.id = f2.id
group by f1.grade, f1.sub_grade
order by f1.grade, f1.sub_grade;


#KPI 3 Total Payment for Verified Status Vs Total Payment for Non Verified Status
select f1.verification_status, 
concat("$", format(round(sum(f2.total_pymnt)/1000000,2),2),"M") as total_payment
from finance_1 as f1 inner join finance_2 as f2
on f1.id = f2.id
group by f1.verification_status;


# KPI 4 State wise and month wise loan status
select addr_state, monthname(last_pymnt_d) as pay_month,  loan_status, count(loan_status)
from finance_1 as f1 join finance_2 as f2
on f1.id = f2.id
group by addr_state,  pay_month, loan_status
order by addr_state, pay_month, loan_status;


# KPI 5 Home ownership Vs last payment date stats
select home_ownership, last_pymnt_d,
concat("$", format(round(sum(last_pymnt_amnt)/10000,2),2),"K") as total_payment
from finance_1 as f1 inner join finance_2 as f2
on f1.id = f2.id
group by home_ownership, last_pymnt_d
order by last_pymnt_d desc, home_ownership desc;


